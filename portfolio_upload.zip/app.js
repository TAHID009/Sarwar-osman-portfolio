(function () {
  const el = (id) => document.getElementById(id);
  const esc = (s) => String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));

  // Shared identity
  document.querySelectorAll("[data-profile-name]").forEach(n => n.textContent = profile.name);
  document.querySelectorAll("[data-profile-shortname]").forEach(n => n.textContent = profile.shortName);
  document.querySelectorAll("[data-profile-title]").forEach(n => n.textContent = profile.professionalTitle);
  document.querySelectorAll("[data-profile-location]").forEach(n => n.textContent = profile.location);

  // Home hero
  if (el("heroLead")) el("heroLead").textContent = profile.summary;
  if (el("heroYears")) el("heroYears").textContent = profile.yearsExperience;
  if (el("heroGds")) el("heroGds").textContent = profile.gdsCount;
  if (el("heroFocus")) el("heroFocus").textContent = profile.focus;

  // Home About teaser (text only, no photo — full photo lives on About page)
  if (el("aboutTeaser")) {
    const short = profile.about.split(". ").slice(0, 2).join(". ") + ".";
    el("aboutTeaser").textContent = short;
  }
  // Home experience teaser (most recent role only)
  if (el("experienceTeaser") && profile.experience[0]) {
    const latest = profile.experience[0];
    el("experienceTeaser").textContent = `Currently ${latest.role} at ${latest.company}, with ${profile.yearsExperience.toLowerCase()} across reservation, ticketing and travel operations.`;
  }

  // Home performance impact strip
  if (el("impactGrid") && profile.impact) {
    el("impactGrid").innerHTML = profile.impact.map((x,i)=>`
      <div class="impact-stat">
        <div class="impact-value" id="impact-value-${i}">${esc(x.value)}</div>
        <div class="impact-label">${esc(x.label)}</div>
        <div class="impact-sub">${esc(x.sub)}</div>
      </div>`).join("");
  }
  if (el("impactNote") && profile.impactNote) el("impactNote").textContent = profile.impactNote;

  // About page
  if (el("aboutText")) el("aboutText").textContent = profile.about;
  if (el("factName")) el("factName").textContent = profile.name;
  if (el("factEmail")) el("factEmail").textContent = profile.email;
  if (el("factLocation")) el("factLocation").textContent = profile.location;
  if (el("factExp")) el("factExp").textContent = profile.yearsExperience;

  // Expertise cards (Home performance visualization + Skills page)
  if (el("expertiseGrid")) {
    el("expertiseGrid").innerHTML = profile.expertise.map((x,i)=>`
      <article class="card">
        <div class="card-icon">${String(i+1).padStart(2,"0")}</div>
        <h3>${esc(x.title)}</h3>
        <p>${esc(x.text)}</p>
        <div class="pills">${x.tags.map(t=>`<span class="pill">${esc(t)}</span>`).join("")}</div>
      </article>`).join("");
  }

  // Full experience timeline (Experience page)
  if (el("experienceFull")) {
    el("experienceFull").innerHTML = profile.experience.map(x=>`
      <article class="job-card">
        ${x.period ? `<div class="job-date"><span class="timeline-dot"></span>${esc(x.period)}</div>` : `<div class="job-date"></div>`}
        <div>
          <h3>${esc(x.role)}</h3>
          <h4>${esc(x.company)} · ${esc(x.location)}</h4>
          <ul>${x.bullets.map(b=>`<li>${esc(b)}</li>`).join("")}</ul>
        </div>
      </article>`).join("");
  }

  // Skills grouped into meaningful categories (no percentage bars)
  if (el("skillGroups")) {
    const catMap = { "GDS":"Systems", "Distribution":"Systems", "Core":"Aviation & Reservation", "Service":"Aviation & Reservation", "Analytics":"Business & Technology", "Productivity":"Business & Technology" };
    const groups = { "Aviation & Reservation": [], "Systems": [], "Business & Technology": [] };
    profile.skills.forEach(([name, cat]) => {
      const group = catMap[cat] || "Aviation & Reservation";
      groups[group].push(name);
    });
    el("skillGroups").innerHTML = Object.entries(groups).map(([group, items]) => `
      <div class="skill-group">
        <h4>${esc(group)}</h4>
        <div class="tag-row">${items.map(i=>`<span class="pill">${esc(i)}</span>`).join("")}</div>
      </div>`).join("");
  }

  // Education
  if (el("educationGrid")) {
    el("educationGrid").innerHTML = profile.education.map(x=>`
      <article class="edu-card">
        <h3>${esc(x.degree)}</h3>
        <p><strong>${esc(x.institution)}</strong></p>
      </article>`).join("");
  }

  // Activities
  if (el("activitiesGrid")) {
    el("activitiesGrid").innerHTML = profile.activities.map((x,i)=>`
      <article class="card">
        <div class="card-icon">${String(i+1).padStart(2,"0")}</div>
        <h3>${esc(x[0])}</h3>
        <p>${esc(x[1])}</p>
      </article>`).join("");
  }

  // Hero statement (v2) — same summary text as the v1 hero
  document.querySelectorAll("[data-profile-summary]").forEach(n => n.textContent = profile.summary);

  // Home: career timeline (v2) — most recent roles, first line of detail each
  if (el("homeTimeline")) {
    el("homeTimeline").innerHTML = profile.experience.map(x => `
      <li class="tl-item">
        <div class="tl-when">${esc(x.period || "")}</div>
        <div class="tl-body">
          <h3>${esc(x.role)}</h3>
          <p class="tl-org">${esc(x.company)} · ${esc(x.location)}</p>
          ${x.bullets && x.bullets[0] ? `<p class="tl-note">${esc(x.bullets[0])}</p>` : ""}
        </div>
      </li>`).join("");
  }

  // Home: grouped expertise (v2) — grouped lists, no scores
  if (el("expertiseGroups") && profile.expertiseGroups) {
    el("expertiseGroups").innerHTML = profile.expertiseGroups.map(g => `
      <div class="xp-group">
        <h3>${esc(g.title)}</h3>
        <ul>${g.items.map(i => `<li>${esc(i)}</li>`).join("")}</ul>
      </div>`).join("");
  }

  // Home: research interests (v2)
  if (el("researchList") && profile.researchInterests) {
    el("researchList").innerHTML = profile.researchInterests.map(i => `<li>${esc(i)}</li>`).join("");
  }

  // Home: education timeline (v2)
  if (el("eduTimeline")) {
    el("eduTimeline").innerHTML = profile.education.map(x => `
      <li class="tl-item">
        <div class="tl-body">
          <h3>${esc(x.degree)}</h3>
          <p class="tl-org">${esc(x.institution)}</p>
        </div>
      </li>`).join("");
  }

  // Years of experience (automatic from profile.experienceStart, or profile.yearsExperienceManual)
  document.querySelectorAll("[data-exp-years]").forEach(n => { if (profile.yearsExperience) n.textContent = profile.yearsExperience; });
  document.querySelectorAll("[data-exp-short]").forEach(n => { if (profile.yearsShort) n.textContent = profile.yearsShort; });
  document.querySelectorAll("[data-exp-words]").forEach(n => { if (profile.yearsWords) n.textContent = profile.yearsWords; });

  // Training & Workshops (Home page) — data lives in profile.workshops
  if (el("homeTrainingGrid") && profile.workshops) {
    el("homeTrainingGrid").innerHTML = profile.workshops.map(w => `
      <article class="h-train-card">
        <img class="h-train-img" src="${esc(w.image)}" alt="${esc(w.title)}" loading="lazy">
        <div class="h-train-body">
          <div class="h-train-meta">${w.date ? `<span class="h-train-chip">${esc(w.date)}</span>` : ""}${w.location ? `<span class="h-train-chip">${esc(w.location)}</span>` : ""}</div>
          <h3>${esc(w.title)}</h3>
          ${w.organizer ? `<p class="h-train-org">${esc(w.organizer)}</p>` : ""}
          <p class="h-train-desc">${esc(w.description)}</p>
        </div>
      </article>`).join("");
  }

  // Quote card (Home page) — rotates through profile.quotes every profile.quoteEveryDays days
  if (el("dailyQuote") && Array.isArray(profile.quotes) && profile.quotes.length) {
    const now = new Date();
    const dayNumber = Math.floor(Date.UTC(now.getFullYear(), now.getMonth(), now.getDate()) / 86400000);
    const step = Math.max(1, profile.quoteEveryDays || 1);
    const q = profile.quotes[Math.floor(dayNumber / step) % profile.quotes.length];
    el("dailyQuote").textContent = q.text;
    if (el("dailyQuoteBy")) {
      el("dailyQuoteBy").textContent = q.author ? "— " + q.author : "";
      el("dailyQuoteBy").hidden = !q.author;
    }
  }

  // Contact links (footer + simple text links)
  document.querySelectorAll("[data-email-link]").forEach(a => { a.href = `mailto:${profile.email}`; a.textContent = profile.email; });
  document.querySelectorAll("[data-phone-link]").forEach(a => { a.href = `tel:${profile.phone.replace(/\s+/g,'')}`; a.textContent = profile.phone; });
  document.querySelectorAll("[data-linkedin-link]").forEach(a => { a.href = profile.linkedin; });
  document.querySelectorAll("[data-cv-link]").forEach(a => { a.href = profile.cv; });
  // Icon-only variants: set the link but keep the symbol as visible text
  document.querySelectorAll("[data-email-icon]").forEach(a => { a.href = `mailto:${profile.email}`; a.title = profile.email; });
  document.querySelectorAll("[data-phone-icon]").forEach(a => { a.href = `tel:${profile.phone.replace(/\s+/g,'')}`; a.title = profile.phone; });
  // Rich contact cards: set href on the card, set text only on the inner label (keeps icon/markup intact)
  document.querySelectorAll("[data-email-card]").forEach(a => { a.href = `mailto:${profile.email}`; });
  document.querySelectorAll("[data-phone-card]").forEach(a => { a.href = `tel:${profile.phone.replace(/\s+/g,'')}`; });
  document.querySelectorAll("[data-email-text]").forEach(n => { n.textContent = profile.email; });
  document.querySelectorAll("[data-phone-text]").forEach(n => { n.textContent = profile.phone; });

  // Mobile nav — multi-page links
  const toggle = el("mobileToggle"), links = el("mobileLinks");
  if (toggle && links) {
    links.innerHTML = `<a href="index.html">Home</a><a href="about.html">About</a><a href="experience.html">Experience</a><a href="skills.html">Skills</a><a class="v2-only" href="index.html#projects">Projects</a><a class="v2-only" href="index.html#research">Research</a><a href="education.html">Education</a><a href="activities.html">Activities</a><a href="aeroops.html">AeroOps Desk</a><a href="contact.html">Contact</a>`;
    // The header is sticky and can be anywhere relative to the document depending
    // on scroll, but #mobileLinks is a normal sibling below it in the page flow.
    // Without this, opening the menu while scrolled down places it back up at the
    // header's original (unstuck) spot in the document instead of under the header
    // the user can actually see, so it looks like nothing happened until they
    // scroll back to the top. Pinning it to the viewport and recalculating its
    // position from the header's live bounding box every time it opens (and on
    // resize) keeps it directly under the visible header no matter where the
    // user has scrolled to.
    function positionMobileMenu() {
      const headerBox = document.querySelector(".header");
      if (headerBox) links.style.top = (headerBox.getBoundingClientRect().bottom + 8) + "px";
    }
    toggle.addEventListener("click", () => {
      const opening = !links.classList.contains("open");
      if (opening) positionMobileMenu();
      links.classList.toggle("open");
    });
    window.addEventListener("resize", () => { if (links.classList.contains("open")) positionMobileMenu(); });
  }

  // AeroOps Desk nav label — shows "Login" until unlocked on this device/tab, then "AeroOps Desk"
  function refreshAeroNavLabel() {
    const unlocked = sessionStorage.getItem("aeroUnlocked") === "1";
    document.querySelectorAll('a[href="aeroops.html"]').forEach(a => {
      a.textContent = unlocked ? "AeroOps Desk" : "Login";
    });
  }
  window.refreshAeroNavLabel = refreshAeroNavLabel;
  refreshAeroNavLabel();

  // Highlight the current page in the nav
  const currentPage = (location.pathname.split("/").pop() || "index.html");
  document.querySelectorAll(".nav-links a, #mobileLinks a").forEach(a => {
    if (a.getAttribute("href") === currentPage) a.classList.add("active");
  });

  // Sticky header: subtle shadow once the page is scrolled
  const headerEl = document.querySelector(".header");
  if (headerEl) {
    const toggleScrolled = () => headerEl.classList.toggle("scrolled", window.scrollY > 8);
    toggleScrolled();
    window.addEventListener("scroll", toggleScrolled, { passive: true });
  }
})();
